images = [
    "",
    "p1.png",
    "p2.png",
    "p3.png",
    "back1.png",
    "back2.png",
    "arrow1.png"
];

audio = [
    "sounds/",
    "jump1.wav",
    "jump2.wav",
    "walk1.wav",
    "walk2.wav",
    "land.wav"
]

var curBlockSizeX = 10;
var curBlockSizeY = 10;

function draw() {
    let camy = player.y < 320 - ch/2 ? 320 - ch : 320;
    
    imgIgnoreCutoff(sprites.back1,player.x/3,camy);
    imgIgnoreCutoff(sprites.back1,player.x/3 + 1600,camy);
    imgIgnoreCutoff(sprites.back2,player.x/4,camy);
    imgIgnoreCutoff(sprites.back2,player.x/4 + 1600,camy);
    player.acount+=0.2;
    if(player.acount>3.8) {
        player.acount=0;
    }
    var f = 1;
    if(!player.onGround) {
        f=2;
    } else if (player.v.x) {
        switch(Math.floor(player.acount)) {
            case 0:
                f=1;
                break;
            case 1:
                f=2;
                break;
            case 2:
                f=1;
                break;
            case 3:
                f=3;    
                break;
        }
    } else {
        f=1;
    }
    player.img = sprites[`p${f}`];
    
    centerCameraOn(player.x,camy);

    
    
    drawBlocks();
    drawDeco();
    img(player.img,player.x,player.y,0,player.dir);

    //cursor.sprite = sprites.cursor;
}

function absoluteDraw() {
    rect(mousePosition().x,mousePosition().y,curBlockSizeX,curBlockSizeY,"#16f7e5");
}

function update() {
    let leftRight = false;

    // right
    if(keyDown[k.d]) { 
        player.v.x += 0.3;
        if(player.v.x > 4) {player.v.x = 4;}
        player.dir = 1;
        leftRight = true;
    }

    // left
    if(keyDown[k.a]) { 
        player.v.x -= 0.3;
        if(player.v.x < -4) {player.v.x = -4;}
        player.dir = -1;
        leftRight = true;
    }

    // jump
    if((keyDown[k.w] || keyDown[k.SPACE]) && player.onGround) {
        player.v.y = -7;
        player.onGround = 0;
        if(player.follow) {
            let b = movingBlocks[player.follow];
            player.v2.x = ((b.x2-b.x1)/100) * b.dir;
            player.v.y += ((b.y2-b.y1)/100) * b.dir;
        }
        play(sounds[`jump${rand(1,2)}`]);
    }

   

    //friction
    if(!leftRight) {
        if(player.v.x > 0) {
            player.v.x -= 0.3;
        }
        if(player.v.x < 0) {
            player.v.x += 0.3;
        }
        if(player.v.x > -0.5 && player.v.x < 0.5) {
            player.v.x = 0;
        }
        if(player.v2.x > 0) {
            player.v2.x -= 0.3;
        }
        if(player.v2.x < 0) {
            player.v2.x += 0.3;
        }
        if(player.v2.x > -0.5 && player.v2.x < 0.5) {
            player.v2.x = 0;
        }
    } else {
        play(sounds[`walk${rand(1,2)}`]);
    }

    if(player.follow) {
        player.onGround = 1;
    }

    //gravity
    if(player.v.y<10 && !player.onGround) {
        player.v.y += 0.2;
    }

    //x
    player.x += player.v.x;
    player.x += player.v2.x;
    let h = hittingStuff();
    let m = hittingMove();
    if(h||m) {
        player.x -= player.v.x;
        player.x -= player.v2.x;
        player.v.x = 0;
    }
    
    //y
    player.y += player.v.y;
    h = hittingStuff();
    m = hittingMove();
    if(h||m) {
        player.y -= player.v.y;

        if(player.v.y > 0) {
            player.onGround = 1;
            if(m) {
                player.follow = m[0];
            }
            if(h) {
                player.y = blocks[h[0]].y - blocks[h[0]].h/2 - player.h/2 - 1;
            } else {
                player.y = movingBlocks[m[0]].y - movingBlocks[m[0]].h/2 - player.h/2 - 1;
            }
        } else if(player.v.y < 0) {
            player.v.y = 0;
        }
    } else {
        player.onGround = 0;
    }

    if(keyDown[k.SHIFT]) {
        curBlockSizeX += scroll;
    } else {
        curBlockSizeY += scroll
    }

    if(mousePress[0]) {
        console.log(`blocks.push(new block(${mousePosition().x},${mousePosition().y},${curBlockSizeX},${curBlockSizeY},"color"));`);
    }


    for(let i = 0;i < movingBlocks.length;i++) {
        movingBlocks[i].update(i);
    }
}

var c = {
    green:"#498c31",
    dirt:"#4d3b26",
};

function onAssetsLoaded() {

    blocks.push(new block(-3500,5000,5000,10000,c.green));


    //grassland
    blocks.push(new block(280,510,150,80,c.green));
    blocks.push(new block(280,520,150,60,c.dirt));
    blocks.push(new block(565,400,170,20,c.green));
    blocks.push(new block(880,440,170,220,c.green));
    blocks.push(new block(880,450,170,200,c.dirt));
    blocks.push(new block(1018,500,110,130,c.green));
    blocks.push(new block(1018,510,110,110,c.dirt));
    blocks.push(new block(1360,485,110,150,c.green));
    blocks.push(new block(1360,495,110,130,c.dirt));

    blocks.push(new block(0,560,4000,20,c.green));
    blocks.push(new block(0,600,4000,80,c.dirt));
}
/*
                test world
                
blocks.push(new block(200,500,100,100,"red"));
    blocks.push(new block(450,450,100,200,"orange"));
    blocks.push(new block(550,500,100,100,"orange"));
    blocks.push(new block(700,300,150,25,"yellow"));
    blocks.push(new block(1000,350,150,25,"yellow"));
    blocks.push(new block(1350,430,100,240,"green"));
    blocks.push(new block(1450,490,100,125,"green"));
    movingBlocks.push(new movingBlock(1700,1700,200,400,100,25,"#001cd1"));
    movingBlocks.push(new movingBlock(2000,2000,100,300,100,25,"#001cd1"));
    blocks.push(new block(2250,300,100,600,"#7c00c9"));
    movingBlocks.push(new movingBlock(500,1000,100,500,100,100,"yellow"));
    movingBlocks.push(new movingBlock(0,200,500,500,100,100,"yellow"));

    blocks.push(new block(0,600,10000,100,"gray"));
*/
setup(60);