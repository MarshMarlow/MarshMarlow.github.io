var player = {
    x:0,
    y:0,
    w:20,
    h:50,
    v:{x:0,y:0},
    v2:{x:0,y:0},
    img:sprites.p1,
    dir:-1,
    onGround:0,
    acount:0,
    follow:undefined
}

